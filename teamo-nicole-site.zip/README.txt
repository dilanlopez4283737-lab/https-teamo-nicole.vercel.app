INSTRUCCIONES PARA SUBIR LA PÁGINA
Archivos incluidos: index.html

1) OPCIÓN RÁPIDA: GitHub Pages
   - Crea un repositorio público en GitHub llamado, por ejemplo, 'teamo-nicole'.
   - Sube index.html (y opcionalmente tu archivo music.mp3).
   - Ve a Settings > Pages y selecciona la rama 'main' y carpeta '/'.
   - Tu página estará en: https://<tu-usuario>.github.io/teamo-nicole/

2) OPCIÓN RÁPIDA: Vercel
   - Crea una cuenta en vercel.com, sube el proyecto o conecta el repo. Se desplegará automáticamente.
   - Sube index.html y music.mp3 al root; el enlace será tipo: https://teamo-nicole.vercel.app

3) Si quieres que yo genere el código QR final, dime la URL resultante y te devuelvo el PNG del QR.

NOTAS:
- Para que la música suene sin errores, sube un archivo 'music.mp3' al mismo directorio que index.html o edita index.html para apuntar a una URL externa de mp3.
- El botón 'Copiar mensaje' copiará el texto para enviar en WhatsApp o mensajería.
